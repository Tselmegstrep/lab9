$source = "C:\ProgramData\MySQL\MySQL Server 8.0\Data\216-22.log"
$destination = "C:\audit_logs\216-22"

#while ($true) {
#    Copy-Item $source -Destination $destination -Force
#    Start-Sleep -Seconds 3
#}
while ($true) {
    Copy-Item $source -Destination $destination -Force
    Write-Host "Copied at $(Get-Date)" -ForegroundColor Green
    Start-Sleep -Seconds 3
}